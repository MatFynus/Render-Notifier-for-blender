# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.


bl_info = {
    "name": "Render Notifier",
    "author": "Matthias Westhoff",
    "version": (1, 0),
    "blender": (2, 80, 0),
    "location": "",
    "description": "Notifies you when your render is finished",
    "warning": "The email address And password wont be send to us or anyone else. Though we still recomend you to create a new e mail address. (Only gmail addresses are supported at the moment)",
    "wiki_url": "https://github.com/MatFynus/Render-Notifier-for-blender/wiki/Wiki",
    "category": "Render Setting",
}

import bpy
from bpy.types import Operator, AddonPreferences
from bpy.app.handlers import persistent
import smtplib, ssl
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from bpy.props import StringProperty


@persistent
def my_handler(scene):

    if bpy.context.scene.rn_tool.RN_bool == True:

        name = bpy.path.basename(bpy.context.blend_data.filepath)[:-6]

        bpy.data.images["Render Result"].save_render(f"{bpy.context.scene.render.filepath}{name}.png")


        fromaddr = bpy.context.preferences.addons['rendernotifier'].preferences['emailaddress']
        toaddr = bpy.context.preferences.addons['rendernotifier'].preferences['emailaddress']



        # instance of MIMEMultipart
        msg = MIMEMultipart()

        # storing the senders email address
        msg['From'] = fromaddr

        # storing the receivers email address
        msg['To'] = toaddr

        # storing the subject
        msg['Subject'] = "Your render is finished"

        # string to store the body of the mail
        body = """
        Hey!

        Seams that your render is finished! """

        # attach the body with the msg instance
        msg.attach(MIMEText(body, 'plain'))

        # open the file to be sent
        filename = f'{name}.png'
        attachment = open(f'{bpy.context.scene.render.filepath}{name}.png', "rb")

        # instance of MIMEBase and named as p
        p = MIMEBase('application', 'octet-stream')

        # To change the payload into encoded form
        p.set_payload((attachment).read())

        # encode into base64
        encoders.encode_base64(p)

        p.add_header('Content-Disposition', "attachment; filename= %s" % filename)

        # attach the instance 'p' to instance 'msg'
        msg.attach(p)

        # creates SMTP session
        s = smtplib.SMTP('smtp.gmail.com', 587)

        # start TLS for security
        s.starttls()

        # Authentication
        s.login(fromaddr, bpy.context.preferences.addons['rendernotifier'].preferences['Password'])

        # Converts the Multipart msg into a string
        text = msg.as_string()

        # sending the mail
        s.sendmail(fromaddr, toaddr, text)

        # terminating the session
        s.quit()



class prefpanle(bpy.types.AddonPreferences):
    bl_idname = __name__

    Password: StringProperty(
        name="Your Password",
        description="Enter your email password",
        default="",
        subtype="PASSWORD",

    )

    emailaddress: StringProperty(
        name="Your email address",
        description="Enter your email address",
        default="",
        subtype="BYTE_STRING",

    )

    def draw(self, context):
        layout = self.layout
        layout.label(text="Your email adress details:")
        layout.prop(self, "emailaddress")
        layout.prop(self, "Password")
        layout.operator("page.google", text="Click me")
        layout.operator("mail.google", text="Need to create a gmail?")




class addon_pref(Operator):
    """Display example preferences"""
    bl_idname = "object.addon_prefs"
    bl_label = "Add-on Preferences"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        preferences = context.preferences
        addon_prefs = preferences.addons[__name__].preferences

        info = ("Path: %s, Number: %d, Boolean %r" %
                (addon_prefs.filepath, addon_prefs.number, addon_prefs.boolean))

        self.report({'INFO'}, info)
        print(info)

        return {'FINISHED'}


class gpage(Operator):
    bl_idname = 'page.google'
    bl_label = 'Cklick on me'
    bl_description = 'Opens a google website to activate the permission in order to use the addon'
    bl_options = {'REGISTER', 'UNDO'}

    def execute (self, context):
        bpy.ops.wm.url_open(url="https://myaccount.google.com/lesssecureapps")
        return{'FINISHED'}

class createemail(Operator):
    bl_idname = 'mail.google'
    bl_label = 'need to create a gmail?'
    bl_description = 'Opens a google website in order to create a gmail in order to use the addon.'
    bl_options = {'REGISTER', 'UNDO'}

    def execute (self, context):
        bpy.ops.wm.url_open(url="https://accounts.google.com/signup/v2/webcreateaccount?flowName=GlifWebSignIn&flowEntry=SignUp")
        return{'FINISHED'}


class RN_settings(bpy.types.PropertyGroup):

    RN_bool: bpy.props.BoolProperty(
        name='Activate Notifier',
        default=True
    )



def draw(self, context):
    layout = self.layout
    rn_tool = context.scene.rn_tool

    row = layout.row()
    row.prop(rn_tool, "RN_bool")










def register():
    bpy.app.handlers.render_complete.append(my_handler)
    bpy.utils.register_class(prefpanle)
    bpy.utils.register_class(addon_pref)
    bpy.utils.register_class(gpage)
    bpy.utils.register_class(createemail)
    bpy.types.Scene.Password = StringProperty(name="Password")
    bpy.types.Scene.emailaddress = StringProperty(name="emailaddress")
    bpy.types.TOPBAR_MT_render.append(draw)
    bpy.utils.register_class(RN_settings)
    bpy.types.Scene.rn_tool = bpy.props.PointerProperty(type=RN_settings)


def unregister():
    bpy.app.handlers.render_complete.remove(my_handler)
    bpy.utils.unregister_class(prefpanle)
    bpy.utils.unregister_class(addon_pref)
    bpy.utils.unregister_class(gpage)
    bpy.utils.unregister_class(createemail)
    bpy.types.TOPBAR_MT_render.remove(draw)
    bpy.utils.unregister_class(RN_settings)
    del bpy.types.Scene.Password
    del bpy.types.Scene.emailaddress
    del bpy.types.Scene.rn_tool


if __name__ == '__main__':
    register()
